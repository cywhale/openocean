#' testapi: testing and trial functions for API
#'
#' The testapi package provides some small functions to test API (e.g. opencpu)
#'
#' @section testapi functions:
#' genx_rdt
#' plot_test
#' @docType package
#' @name testapi
NULL

#' @importFrom magrittr %>%
#' @importFrom ggrepel geom_label_repel
#' @importFrom ggrepel geom_text_repel
#' @importFrom ggforce geom_shape
#' @importFrom grid makeContent

NULL

#' generate and write data or test data
#' @param rand_seed An integer to specify random seed
#' @param L An integer to specify data amount for generating random data
#' @param P An integer to specify column numbers, so the total rows is as.integer(L/P)
#' @seealso \code{\link{data.table::fwrite}} for parameter and ... description
#' @return A data.table/data.frame and write into a file
#' @examples genx_rdt()
#' @rdname genx_rdt
#' @export
genx_rdt <- function(x=NULL, file=NA_character_, rand_seed=NULL, L=1e4, P=10, ...) {

  if (!is.null(rand_seed)) set.seed(rand_seed)

  if (is.null(x)) {
    x <- matrix(runif(L), as.integer(L/P)) %>% data.table() #%>%
      #setnames(1:P,sample(LETTERS,P)) %>% .[,SP:=seq_len(nrow(.))]
  } else {
    x <- setDT(x)
  }

  if (!is.na(file)) {
    data.table::fwrite(x, file = file, ...)
  }
  return(x)
}

#' generate a test graph by ggplot+ggrepel, use offical ex: https://cran.r-project.org/web/packages/ggrepel/vignettes/ggrepel.html
#' @return A ggplot graph
#' @examples plot_test()
#' @rdname plot_test
#' @export
plot_test <- function() {
  set.seed(42)
  data("mtcars")
  dat2 <- subset(mtcars, wt > 3 & wt < 4)
  # Hide all of the text labels.
  dat2$car <- ""
  # Let's just label these items.
  ix_label <- c(2,3,16)
  dat2$car[ix_label] <- rownames(dat2)[ix_label]

  g1 <- ggplot(dat2, aes(wt, mpg, label = car)) +
    geom_point(color = ifelse(dat2$car == "", "grey50", "red")) +
    geom_text_repel() +
    geom_text(data=data.frame(x=3.5, y=20, lab="Test geom_text and ggforce:geom_shape!"), aes(x,y,label=lab), col="red") +
    ggforce::geom_shape(data=data.frame(
      x = c(3.5, 4, 3.75, 3.25, 3),
      y = c(19.5, 20, 20.5, 20.25, 19.75)
    ), aes(x=x,y=y), radius = unit(0.15, 'cm'), col="red", fill='transparent', inherit.aes = FALSE)
    #geom_polygon(data=poly, aes(x=x,y=y), col='red') +

  print(g1)
}
